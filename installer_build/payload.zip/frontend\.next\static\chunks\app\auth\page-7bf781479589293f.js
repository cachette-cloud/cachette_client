(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[365],{1766:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>q});var a=r(5155),n=r(2115),i=r(2222),o=r(5556),l=r(9406);r(2399);let s=`#version 300 es
in vec2 aPosition;
void main() {
  gl_Position = vec4(aPosition, 0.0, 1.0);
}`,u=`#version 300 es
precision highp float;
uniform vec2 uResolution;
uniform float uDpr;
uniform int uShape;
uniform float uSides;
uniform vec2 uHalf;
uniform float uRadius;
uniform float uRound;
uniform sampler2D uFieldTexture;
uniform vec2 uField;
uniform float uThickness;
uniform float uFill;
uniform float uEchoes;
uniform float uSpacing;
uniform float uAngle;
out vec4 outColor;

const float PI = 3.14159265;

float sdRoundBox(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - b + r;
  return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

float sdPolygon(vec2 p, float r, float n) {
  float an = PI / n;
  vec2 acs = vec2(cos(an), sin(an));
  float bn = mod(atan(p.x, p.y), 2.0 * an) - an;
  p = length(p) * vec2(cos(bn), abs(sin(bn)));
  p -= r * acs;
  p.y += clamp(-p.y, 0.0, r * acs.y);
  return length(p) * sign(p.x);
}

float sdStar(vec2 p, float r, float n, float m) {
  float an = PI / n;
  float en = PI / m;
  vec2 acs = vec2(cos(an), sin(an));
  vec2 ecs = vec2(cos(en), sin(en));
  float bn = mod(atan(p.x, p.y), 2.0 * an) - an;
  p = length(p) * vec2(cos(bn), abs(sin(bn)));
  p -= r * acs;
  p += ecs * clamp(-dot(p, ecs), 0.0, r * acs.y / ecs.y);
  return length(p) * sign(p.x);
}

float shapeDistance(vec2 p) {
  if (uShape < 0) return 1e5;
  float c = cos(uAngle);
  float s = sin(uAngle);
  p = mat2(c, -s, s, c) * p;
  if (uShape == 0) return sdRoundBox(p, uHalf, uRound);
  if (uShape == 1) return length(p) - uRadius;
  if (uShape == 2) return sdPolygon(p, uRadius - uRound, uSides) - uRound;
  if (uShape == 3) return sdStar(p, uRadius - uRound, uSides, mix(2.0, uSides, 0.42)) - uRound;
  vec2 uv = p / (2.0 * uField.x) + 0.5;
  vec2 inside = clamp(uv, 0.0, 1.0);
  float d = texture(uFieldTexture, vec2(inside.x, 1.0 - inside.y)).r * uField.y;
  return d + length((uv - inside) * 2.0 * uField.x);
}

void main() {
  vec2 p = gl_FragCoord.xy / uDpr - 0.5 * uResolution;
  float d = shapeDistance(p);
  float aa = 1.0 / uDpr;
  float hw = 0.5 * uThickness;
  float cover = uFill > 0.5 ? clamp(0.5 - d / aa, 0.0, 1.0) : 0.0;
  for (int i = 0; i < 24; i++) {
    if (float(i) >= uEchoes) break;
    if (uFill > 0.5 && i == 0) continue;
    float x = uFill > 0.5 ? d - float(i) * uSpacing : d + float(i) * uSpacing;
    cover = max(cover, clamp((hw - abs(x)) / aa + 0.5, 0.0, 1.0));
  }
  outColor = vec4(cover, 0.0, 0.0, 1.0);
}`,c=`#version 300 es
precision highp float;
uniform sampler2D uSource;
uniform float uLod;
uniform vec2 uStep;
uniform vec2 uScale;
out vec4 outColor;

void main() {
  vec2 size = vec2(textureSize(uSource, int(uLod)));
  vec2 center = gl_FragCoord.xy * uScale;
  float sum = textureLod(uSource, center / size, uLod).r * 6.0;
  sum += textureLod(uSource, (center - uStep) / size, uLod).r * 4.0;
  sum += textureLod(uSource, (center + uStep) / size, uLod).r * 4.0;
  sum += textureLod(uSource, (center - 2.0 * uStep) / size, uLod).r;
  sum += textureLod(uSource, (center + 2.0 * uStep) / size, uLod).r;
  outColor = vec4(sum / 16.0, 0.0, 0.0, 1.0);
}`,d=`#version 300 es
precision highp float;
uniform sampler2D uPyramid;
uniform float uMaxLod;
uniform vec2 uResolution;
uniform float uDpr;
uniform float uThickness;
uniform float uFill;
uniform float uEchoes;
uniform float uSpacing;
uniform vec3 uColor;
uniform float uBackdrop;
uniform float uBlur;
uniform vec3 uLens;
uniform vec2 uLensShape;
uniform float uFocus;
uniform float uChroma;
out vec4 outColor;

float bspline(vec2 uv, float lod) {
  vec2 size = vec2(textureSize(uPyramid, int(lod)));
  vec2 st = uv * size - 0.5;
  vec2 i = floor(st);
  vec2 f = st - i;
  vec2 f2 = f * f;
  vec2 f3 = f2 * f;
  vec2 w0 = (1.0 - 3.0 * f + 3.0 * f2 - f3) / 6.0;
  vec2 w1 = (4.0 - 6.0 * f2 + 3.0 * f3) / 6.0;
  vec2 w2 = (1.0 + 3.0 * f + 3.0 * f2 - 3.0 * f3) / 6.0;
  vec2 w3 = f3 / 6.0;
  vec2 g0 = w0 + w1;
  vec2 g1 = w2 + w3;
  vec2 p0 = (i - 0.5 + w1 / g0) / size;
  vec2 p1 = (i + 1.5 + w3 / g1) / size;
  float a = textureLod(uPyramid, p0, lod).r;
  float b = textureLod(uPyramid, vec2(p1.x, p0.y), lod).r;
  float c = textureLod(uPyramid, vec2(p0.x, p1.y), lod).r;
  float d = textureLod(uPyramid, p1, lod).r;
  return g0.y * (g0.x * a + g1.x * b) + g1.y * (g0.x * c + g1.x * d);
}

float blurred(vec2 uv, float sigma) {
  if (sigma <= 0.6) return textureLod(uPyramid, uv, 0.0).r;
  float lod = sigma < 1.7 ? (sigma - 0.6) / 1.1 : log2(sigma / 0.866);
  lod = clamp(lod, 0.0, uMaxLod);
  float base = floor(lod);
  float t = lod - base;
  float a = base < 0.5 ? textureLod(uPyramid, uv, 0.0).r : bspline(uv, base);
  if (t < 0.001) return a;
  return mix(a, bspline(uv, min(base + 1.0, uMaxLod)), t);
}

void main() {
  vec2 texel = 1.0 / vec2(textureSize(uPyramid, 0));
  vec2 uv = gl_FragCoord.xy * texel;
  vec2 p = gl_FragCoord.xy / uDpr - 0.5 * uResolution;
  vec2 toLens = p - uLens.xy;
  float lensDistance = length(toLens);
  float lens = uLens.z * (1.0 - smoothstep(uLensShape.x * (1.0 - uLensShape.y), uLensShape.x, lensDistance));
  float amount = mix(lens, 1.0 - lens, uFocus);
  float sigma = uBlur * amount * uDpr;
  vec2 dir = lensDistance > 0.001 ? toLens / lensDistance : vec2(0.0);
  vec2 split = dir * uChroma * 0.3 * sigma * texel;
  vec3 cover = vec3(
    blurred(uv - split, sigma * (1.0 + uChroma * 0.25)),
    blurred(uv, sigma),
    blurred(uv + split, sigma * (1.0 - uChroma * 0.2))
  );
  if (uFill < 0.5) {
    float spread = sigma / uDpr;
    float reach = uEchoes > 1.5 ? min(spread, uSpacing) : spread;
    cover *= 1.0 + 0.6 * max(reach - 0.5, 0.0) / max(uThickness, 0.5);
  }
  cover = mix(cover, 0.85 + 0.15 * (1.0 - exp((0.85 - cover) / 0.15)), step(0.85, cover));
  float grain = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
  cover = clamp(cover + grain / 255.0, 0.0, 1.0);
  float alpha = max(max(cover.r, cover.g), cover.b);
  outColor = vec4(uColor * cover + (alpha - cover) * uBackdrop, alpha);
}`,f=["rect","circle","polygon","star"],m=(e,t,r)=>Math.min(r,Math.max(t,e)),h=(e,t,r)=>{let a=e.createShader(t);return a?(e.shaderSource(a,r),e.compileShader(a),e.getShaderParameter(a,e.COMPILE_STATUS))?a:(e.deleteShader(a),null):null},p=(e,t,r)=>{let a=h(e,e.FRAGMENT_SHADER,r),n=e.createProgram();return a&&n?(e.attachShader(n,t),e.attachShader(n,a),e.bindAttribLocation(n,0,"aPosition"),e.linkProgram(n),e.deleteShader(a),e.getProgramParameter(n,e.LINK_STATUS))?n:(e.deleteProgram(n),null):null},x=(e,t,r)=>{let a={};for(let n of r)a[n]=e.getUniformLocation(t,n);return a},g=(e,t,r,a,n,i,o)=>{for(let i=0;i<a;i++)n[i]=e[t+i*r];let l=0;i[0]=0,o[0]=-1e20,o[1]=1e20;for(let e=1;e<a;e++){let t=(n[e]+e*e-(n[i[l]]+i[l]*i[l]))/(2*(e-i[l]));for(;t<=o[l];)l--,t=(n[e]+e*e-(n[i[l]]+i[l]*i[l]))/(2*(e-i[l]));i[++l]=e,o[l]=t,o[l+1]=1e20}l=0;for(let s=0;s<a;s++){for(;o[l+1]<s;)l++;let a=s-i[l];e[t+s*r]=a*a+n[i[l]]}},v=(e,t)=>{let r=new Float64Array(t),a=new Int32Array(t),n=new Float64Array(t+1);for(let i=0;i<t;i++)g(e,i,t,t,r,a,n);for(let i=0;i<t;i++)g(e,i*t,1,t,r,a,n)},y=({shape:e="rect",src:t="",sides:r=6,size:i=.8,roundness:o=.2,thickness:l=2,fill:g=!1,echoes:y=1,spacing:w=12,color:E="#ffffff",blur:b=16,lensSize:T=.3,lensSoftness:R=.7,focus:S=!1,chroma:_=.3,rotation:M=0,spin:L=0,idle:A=!0,children:C,className:j="",style:P})=>{let F=(0,n.useRef)(null),N=(0,n.useRef)(null),D=(0,n.useRef)(null),z={shape:Math.max(0,f.indexOf(e)),src:t||"",sides:m(Math.round(r),3,12),size:m(i,.05,1),roundness:m(o,0,1),thickness:m(l,.5,40),fill:g,echoes:m(Math.round(y),1,24),spacing:Math.max(1,w),color:E,blur:Math.max(0,b),lensSize:m(T,.02,2),lensSoftness:m(R,0,1),focus:S,chroma:m(_,0,1),rotation:M,spin:L,idle:A},k=(0,n.useRef)(z);return k.current=z,(0,n.useEffect)(()=>{let e=F.current,t=N.current,r=t?.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1});if(!e||!t||!r)return;let a=h(r,r.VERTEX_SHADER,s);if(!a)return;let n=p(r,a,u),i=p(r,a,c),o=p(r,a,d);if(!n||!i||!o)return;let l=x(r,n,["uResolution","uDpr","uShape","uSides","uHalf","uRadius","uRound","uFieldTexture","uField","uThickness","uFill","uEchoes","uSpacing","uAngle"]),f=x(r,i,["uSource","uLod","uStep","uScale"]),m=x(r,o,["uPyramid","uMaxLod","uResolution","uDpr","uThickness","uFill","uEchoes","uSpacing","uColor","uBackdrop","uBlur","uLens","uLensShape","uFocus","uChroma"]),g=r.createVertexArray();r.bindVertexArray(g);let y=r.createBuffer();r.bindBuffer(r.ARRAY_BUFFER,y),r.bufferData(r.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),r.STATIC_DRAW),r.enableVertexAttribArray(0),r.vertexAttribPointer(0,2,r.FLOAT,!1,0,0);let w=r.getExtension("EXT_color_buffer_float")?r.R16F:r.R8,E=r.createFramebuffer(),b=r.createTexture();r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,b),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),r.texImage2D(r.TEXTURE_2D,0,r.R16F,1,1,0,r.RED,r.FLOAT,new Float32Array([1e4]));let T=document.createElement("canvas");T.width=1,T.height=1;let R=T.getContext("2d",{willReadFrequently:!0}),S=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,_={x:0,y:0,active:!1},M={x:0,y:0,power:0,placed:!1},L={texture:null,temps:[],sizes:[],levels:0,key:""},A={width:1,height:1,dpr:1,time:0,angle:0,color:[1,1,1],backdrop:0,colorKey:"",image:"none",request:0},C=0,j=0,P=!0,z=!0,U=()=>{let e=k.current;if(!L.texture)return;(e=>{if(e===A.colorKey)return;A.colorKey=e,t.style.color=e;let r=getComputedStyle(t).color;if(t.style.color="",!R)return;R.clearRect(0,0,1,1),R.fillStyle=r,R.fillRect(0,0,1,1);let[a,n,i]=R.getImageData(0,0,1,1).data;A.color=[a/255,n/255,i/255],A.backdrop=+(.2126*A.color[0]+.7152*A.color[1]+.0722*A.color[2]<.5)})(e.color),r.bindVertexArray(g),r.disable(r.BLEND),(e=>{let{width:a,height:o}=A,s=Math.min(a,o)/2,u=(1-e.size)*s,c=Math.max(1,a/2-u),d=Math.max(1,o/2-u),m=e.size*s,h=1.35*m,p=e.shape;e.src&&(p="ready"===A.image?4:"failed"===A.image?e.shape:-1);let x=0===p?e.roundness*Math.min(c,d):e.roundness*m*(3===p?.12:.3),g=(e.rotation+A.angle)*Math.PI/180,v=[t.width,t.height,p,e.sides,c,d,m,x,e.thickness,e.fill,e.echoes,e.spacing,g.toFixed(5)].join("|");if(v!==L.key){L.key=v,r.bindFramebuffer(r.FRAMEBUFFER,E),r.framebufferTexture2D(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,L.texture,0),r.viewport(0,0,L.sizes[0][0],L.sizes[0][1]),r.useProgram(n),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,b),r.uniform1i(l.uFieldTexture,0),r.uniform2f(l.uResolution,a,o),r.uniform1f(l.uDpr,A.dpr),r.uniform1i(l.uShape,p),r.uniform1f(l.uSides,e.sides),r.uniform2f(l.uHalf,c,d),r.uniform1f(l.uRadius,m),r.uniform1f(l.uRound,x),r.uniform2f(l.uField,h,2*h/512),r.uniform1f(l.uThickness,e.thickness),r.uniform1f(l.uFill,+!!e.fill),r.uniform1f(l.uEchoes,e.echoes),r.uniform1f(l.uSpacing,e.spacing),r.uniform1f(l.uAngle,g),r.drawArrays(r.TRIANGLES,0,3),r.useProgram(i),r.uniform1i(f.uSource,0);for(let e=1;e<L.levels;e++)r.framebufferTexture2D(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,L.temps[e],0),r.viewport(0,0,L.sizes[e][0],L.sizes[e-1][1]),r.bindTexture(r.TEXTURE_2D,L.texture),r.uniform1f(f.uLod,e-1),r.uniform2f(f.uStep,1,0),r.uniform2f(f.uScale,2,1),r.drawArrays(r.TRIANGLES,0,3),r.framebufferTexture2D(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,L.texture,e),r.viewport(0,0,L.sizes[e][0],L.sizes[e][1]),r.bindTexture(r.TEXTURE_2D,L.temps[e]),r.uniform1f(f.uLod,0),r.uniform2f(f.uStep,0,1),r.uniform2f(f.uScale,1,2),r.drawArrays(r.TRIANGLES,0,3);r.bindFramebuffer(r.FRAMEBUFFER,null)}})(e);let{width:a,height:s}=A;r.viewport(0,0,t.width,t.height),r.useProgram(o),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,L.texture),r.uniform1i(m.uPyramid,0),r.uniform1f(m.uMaxLod,L.levels-1),r.uniform2f(m.uResolution,a,s),r.uniform1f(m.uDpr,A.dpr),r.uniform1f(m.uThickness,e.thickness),r.uniform1f(m.uFill,+!!e.fill),r.uniform1f(m.uEchoes,e.echoes),r.uniform1f(m.uSpacing,e.spacing),r.uniform3f(m.uColor,A.color[0],A.color[1],A.color[2]),r.uniform1f(m.uBackdrop,A.backdrop),r.uniform1f(m.uBlur,e.blur),r.uniform3f(m.uLens,M.x,M.y,M.power),r.uniform2f(m.uLensShape,e.lensSize*Math.min(a,s),e.lensSoftness),r.uniform1f(m.uFocus,+!!e.focus),r.uniform1f(m.uChroma,e.chroma),r.clearColor(0,0,0,0),r.clear(r.COLOR_BUFFER_BIT),r.drawArrays(r.TRIANGLES,0,3)},I=e=>{if(C=0,!z||!P)return;let t=k.current,r=j?Math.min(.05,(e-j)/1e3):1/60;j=e,A.time+=r,S||(A.angle=(A.angle+t.spin*r)%360);let a=!_.active&&t.idle&&!S,n=M.x,i=M.y,o=0;if(_.active)n=_.x,i=_.y,o=1;else if(a){var l;let e,t,r;[n,i]=(l=A.time,e=k.current,t=Math.min(A.width,A.height)/2,r=(1-e.size)*t,[(0!==e.shape||e.src?e.size*t:A.width/2-r)*(.75*Math.sin(.37*l)+.2*Math.sin(1.13*l+1.7)),(0!==e.shape||e.src?e.size*t:A.height/2-r)*(.7*Math.sin(.53*l+.9)+.2*Math.cos(.91*l+.4))]),o=.85}M.placed||(M.x=n,M.y=i,M.placed=!0);let s=1-Math.exp(-r*(_.active?10:3));M.x+=(n-M.x)*s,M.y+=(i-M.y)*s,M.power+=(o-M.power)*(1-Math.exp(-(4*r))),U(),!(.1>Math.abs(n-M.x)&&.1>Math.abs(i-M.y)&&.002>Math.abs(o-M.power))||a||t.spin&&!S?C=requestAnimationFrame(I):j=0},O=()=>{!C&&z&&P&&(C=requestAnimationFrame(I))},X=t=>{let r=e.getBoundingClientRect(),a=k.current.lensSize*Math.min(r.width,r.height),n=t.clientX-r.left,i=t.clientY-r.top;_.active=n>-a&&i>-a&&n<r.width+a&&i<r.height+a,_.x=n-r.width/2,_.y=r.height/2-i,O()},B=()=>{_.active=!1,O()},$=()=>{A.dpr=Math.min(window.devicePixelRatio||1,2),A.width=Math.max(1,e.clientWidth),A.height=Math.max(1,e.clientHeight),t.width=Math.round(A.width*A.dpr),t.height=Math.round(A.height*A.dpr),(()=>{L.texture&&r.deleteTexture(L.texture),L.temps.forEach(e=>r.deleteTexture(e));let e=t.width,a=t.height;L.levels=Math.min(10,Math.floor(Math.log2(Math.max(e,a)))+1),L.sizes=[];for(let t=0;t<L.levels;t++)L.sizes.push([Math.max(1,e>>t),Math.max(1,a>>t)]);let n=()=>{r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)};L.texture=r.createTexture(),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,L.texture),r.texStorage2D(r.TEXTURE_2D,L.levels,w,e,a),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR_MIPMAP_NEAREST),n(),L.temps=[null];for(let e=1;e<L.levels;e++){let t=r.createTexture();r.bindTexture(r.TEXTURE_2D,t),r.texStorage2D(r.TEXTURE_2D,1,w,L.sizes[e][0],L.sizes[e-1][1]),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),n(),L.temps.push(t)}L.key=""})(),U(),O()};D.current={load:e=>{let t=++A.request;if(A.image=e?"loading":"none",O(),!e)return;let a=new Image;a.crossOrigin="anonymous",a.onload=()=>{if(!z||t!==A.request)return;let e=null;try{e=(e=>{let t=document.createElement("canvas");t.width=512,t.height=512;let r=t.getContext("2d",{willReadFrequently:!0});if(!r)return null;let a=e.naturalWidth||512,n=e.naturalHeight||512,i=512/1.35/Math.max(a,n);r.drawImage(e,(512-a*i)/2,(512-n*i)/2,a*i,n*i);let o=r.getImageData(0,0,512,512).data,l=new Float64Array(262144),s=new Float64Array(262144);for(let e=0;e<262144;e++){let t=o[4*e+3]/255,r=.5-t;l[e]=t>=.999?0:t<=.001?1e20:r>0?r*r:0,s[e]=t>=.999?1e20:t<=.001?0:r<0?r*r:0}v(l,512),v(s,512);let u=new Float32Array(262144);for(let e=0;e<262144;e++)u[e]=Math.sqrt(l[e])-Math.sqrt(s[e]);return u})(a)}catch{e=null}if(!e){A.image="failed",O();return}r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,b),r.texImage2D(r.TEXTURE_2D,0,r.R16F,512,512,0,r.RED,r.FLOAT,e),A.image="ready",O()},a.onerror=()=>{z&&t===A.request&&(A.image="failed",O())},a.src=e},wake:O};let q=new ResizeObserver($);q.observe(e);let H=new IntersectionObserver(e=>{(P=e.some(e=>e.isIntersecting))&&(j=0,O())});return H.observe(e),window.addEventListener("pointermove",X,{passive:!0}),document.documentElement.addEventListener("pointerleave",B),$(),()=>{z=!1,cancelAnimationFrame(C),D.current=null,q.disconnect(),H.disconnect(),window.removeEventListener("pointermove",X),document.documentElement.removeEventListener("pointerleave",B),L.texture&&r.deleteTexture(L.texture),L.temps.forEach(e=>r.deleteTexture(e)),r.deleteTexture(b),r.deleteFramebuffer(E),r.deleteBuffer(y),r.deleteVertexArray(g),r.deleteProgram(n),r.deleteProgram(i),r.deleteProgram(o),r.deleteShader(a)}},[]),(0,n.useEffect)(()=>{D.current?.load(t||"")},[t]),(0,n.useEffect)(()=>{D.current?.wake()}),(0,a.jsxs)("div",{ref:F,className:`shape-blur${j?` ${j}`:""}`,style:P,children:[(0,a.jsx)("canvas",{ref:N,className:"shape-blur__canvas","aria-hidden":"true"}),C&&(0,a.jsx)("div",{className:"shape-blur__content",children:C})]})};var w=r(9749),E=r(4389),b=r(4460),T=r(5829),R=r(5227),S=r(9064),_=r(3005);r(9557);let M=[.23,1,.32,1],L=e=>Math.min(1,Math.max(0,e)),A=e=>String(e??"").replace(/[^0-9a-zA-Z]/g,"").toUpperCase(),C=(e,t)=>{let r=A(e).slice(0,t);return Array.from({length:t},(e,t)=>r[t]??"")},j=e=>{let t=e.indexOf("");return -1===t?e.length-1:t};function P({length:e=6,value:t,defaultValue:r="",onChange:i,onComplete:o,status:l="idle",mask:s=!1,caret:u=!0,disabled:c=!1,autoFocus:d=!1,accentColor:f="#f5f5f5",inkColor:m="#f5f5f5",slotColor:h="#27272a",digitColor:p="#18181b",dangerColor:x="#ff3b30",slotSize:g=44,gap:v=8,radius:y=12,bounce:w=.2,settle:N=.3,rise:D=8,cascade:z=20,ariaLabel:k="One-time code",className:U="",style:I}){let O=(0,n.useId)(),X=(0,E.I)(),B=(0,n.useRef)(null),$=(0,n.useRef)(null),[q,H]=(0,n.useState)(()=>C(t??r,e)),[G,W]=(0,n.useState)(()=>j(q)),[Y,V]=(0,n.useState)(!1),[K,J]=(0,n.useState)("success"===l),Q=(0,b.d)(G),Z=(0,b.d)(+("success"===l)),ee=(0,b.d)(+("success"===l)),et=(0,n.useRef)(new Set),er=(0,n.useRef)([]),ea=(0,n.useRef)(!1),en=(0,n.useRef)(void 0),ei=(0,n.useRef)(l),eo=(0,n.useRef)(A(t??r).slice(0,e)),el=(0,n.useRef)(q);el.current=q;let es=(0,n.useRef)({});es.current={settle:N,bounce:w,cascade:z,reduce:X};let{mvs:eu,drops:ec}=(0,n.useMemo)(()=>({mvs:Array.from({length:e},(e,t)=>(0,T.OQ)(+!!el.current[t])),drops:Array.from({length:e},()=>(0,T.OQ)(+("success"===ei.current)))}),[e]),ed=g+v,ef=Math.round(1.18*g),em=Math.min(y,g/2),eh=(0,n.useCallback)((e,t,r=0)=>{let a=eu[e];if(!a)return;er.current[e]=t;let n=es.current;n.reduce?a.jump(t):(0,R.i)(a,t,{type:"spring",duration:n.settle,bounce:n.bounce,delay:r/1e3})},[eu]),ep=(0,n.useCallback)((e,t=0)=>{eu[e].get()>0&&eu[e].jump(0),eh(e,1,t)},[eu,eh]),ex=(0,n.useCallback)((e,t)=>{t.forEach(e=>et.current.add(e)),Q.jump(e),W(e)},[Q]),eg=(0,n.useCallback)(e=>{et.current.clear(),Q.jump(e),W(e)},[Q]),ev=(0,S.G)(()=>{let e=Q.get(),t=e*ed;for(let r=0;r<eu.length;r++){let a=L(eu[r].get());if(!et.current.has(r))continue;let n=er.current[r];if(void 0===n||a===L(n)){et.current.delete(r);continue}t+=r<e?-(1-a)*ed:a*ed}return Math.min(Math.max(t,0),(eu.length-1)*ed)}),ey=(0,S.G)(ev,e=>`translateX(${e}px)`),ew=(0,S.G)(Z,e=>`inset(0 ${(1-L(e))*50}% round ${em}px)`),eE=(0,S.G)(ee,e=>`translateY(${(1-e)*8}px) scale(${.85+.15*Math.max(e,0)})`),eb=(0,S.G)(ee,L),eT=(0,n.useCallback)(e=>{let t=el.current;el.current=e,H(e);let r=e.join("");eo.current=r,i?.(r),!t.every(Boolean)&&e.every(Boolean)&&o?.(r)},[i,o]),eR=(t,r=G)=>{let a=A(t);if(!a)return;let n=[...el.current],i=[],o=X?0:z,l=r;for(let t of a){if(l>=e)break;n[l]=t,ep(l,(l-r)*o),i.push(l),l+=1}i.length&&(eT(n),ex(Math.min(l,e-1),i))},eS=(e,t=!1)=>{if(!el.current[e]){t&&eg(e);return}let r=[...el.current];r[e]="",eh(e,0),eT(r),t&&ex(e,[e])},e_=c||ea.current||"success"===l;(0,n.useEffect)(()=>{et.current.clear(),er.current=[];let t=Array.from({length:e},(e,t)=>el.current[t]??"");el.current=t,H(t),eg(j(t));let r=t.join("");r!==eo.current&&(eo.current=r,i?.(r))},[e]),(0,n.useEffect)(()=>{if(void 0===t)return;let r=A(t).slice(0,e);if(r===eo.current)return;eo.current=r;let a=el.current,n=C(r,e),i="success"===ei.current,l=[],s=[];n.forEach((e,t)=>{e!==a[t]&&(e?l:s).push(t)});let u=es.current.reduce||i?0:es.current.cascade;l.forEach((e,t)=>ep(e,t*u)),s.reverse().forEach((e,t)=>{i?(er.current[e]=0,eu[e].jump(0),ec[e].jump(0)):eh(e,0,t*u)}),el.current=n,H(n),ex(j(n),[...l,...s]),!a.every(Boolean)&&n.every(Boolean)&&o?.(r)},[t,e]),(0,n.useEffect)(()=>{let e=ei.current,t=es.current;if("success"===l){if(J(!0),t.reduce){Z.jump(1),ec.forEach(e=>e.jump(1)),ee.jump(1);return}(0,R.i)(Z,1,{duration:.3,ease:M}),ec.forEach((e,t)=>(0,R.i)(e,1,{type:"spring",duration:.3,bounce:0,delay:.06+.03*t})),(0,R.i)(ee,1,{type:"spring",duration:.35,bounce:t.bounce,delay:.28});return}if("success"===e){if(t.reduce){Z.jump(0),ee.jump(0),ec.forEach(e=>e.jump(0)),J(!1);return}(0,R.i)(ee,0,{duration:.15,ease:M}),(0,R.i)(Z,0,{duration:.2,ease:M,delay:.06}).then(()=>{0===Z.get()&&J(!1)}),ec.forEach(e=>(0,R.i)(e,0,{type:"spring",duration:.3,bounce:0,delay:.1}))}},[l]),(0,n.useEffect)(()=>{if("error"!==l)return;let t=el.current.map((e,t)=>e?t:-1).filter(e=>e>=0);if(!t.length)return;t.reverse(),ea.current=!0;let r=es.current,a=r.reduce?0:r.cascade;t.forEach((e,t)=>eh(e,0,t*a)),ex(0,el.current.map((e,t)=>t)),clearTimeout(en.current),en.current=setTimeout(()=>{ea.current=!1,eT(Array.from({length:e},()=>""))},r.reduce?300:(t.length-1)*a+1e3*r.settle)},[l]),(0,n.useEffect)(()=>{ei.current=l},[l]),(0,n.useEffect)(()=>()=>clearTimeout(en.current),[]),(0,n.useEffect)(()=>{d&&B.current?.focus()},[d]);let eM=q.length===e?q:Array.from({length:e},(e,t)=>q[t]??""),eL=u&&Y&&!c&&!K&&"success"!==l&&("error"===l||!eM[G]);return(0,a.jsxs)("div",{className:`code-slots${U?` ${U}`:""}`,style:{"--cs-accent":f,"--cs-ink":m,"--cs-slot":h,"--cs-digit":p,"--cs-danger":x,"--cs-size":`${g}px`,"--cs-height":`${ef}px`,"--cs-gap":`${v}px`,"--cs-radius":`${Math.min(y,g/2)}px`,"--cs-font":`${Math.round(.5*g)}px`},children:[(0,a.jsxs)("div",{ref:$,className:"code-slots__row","data-status":l,"data-focused":Y?"":void 0,"data-disabled":c?"":void 0,onMouseDown:e=>{if(c)return;e.preventDefault();let t=$.current;if(t&&!ea.current&&"success"!==l){let r=t.getBoundingClientRect(),a=r.width/(t.offsetWidth||r.width)||1;eg(Math.max(0,Math.min(Math.floor((e.clientX-r.left)/a/ed),j(el.current))))}B.current?.focus()},children:[(0,a.jsx)("input",{ref:B,className:"code-slots__input",type:"text",inputMode:"text",autoComplete:"one-time-code",value:"",maxLength:e,"aria-label":k,"aria-invalid":"error"===l,"aria-describedby":`${O}-count`,disabled:c,readOnly:"success"===l,onKeyDown:t=>{if(e_||t.metaKey||t.ctrlKey||t.altKey)return;let r=t.key;/^[0-9a-zA-Z]$/.test(r)?(t.preventDefault(),eR(r.toUpperCase())):"Backspace"===r?(t.preventDefault(),q[G]?eS(G):G>0&&eS(G-1,!0)):"Delete"===r?(t.preventDefault(),eS(G)):"ArrowLeft"===r?(t.preventDefault(),eg(Math.max(G-1,0))):"ArrowRight"===r?(t.preventDefault(),eg(Math.min(G+1,e-1))):"Home"===r?(t.preventDefault(),eg(0)):"End"===r&&(t.preventDefault(),eg(e-1))},onPaste:e=>{e_||(e.preventDefault(),eR(e.clipboardData.getData("text")))},onChange:e=>{if(e_)return;let t=A(e.target.value);t&&eR(t,1===t.length?G:0)},onFocus:()=>V(!0),onBlur:()=>V(!1)}),eM.map((e,t)=>(0,a.jsx)(F,{mv:eu[t],drop:ec[t],char:s&&e?"•":e,active:Y&&t===G,rise:D,sink:Math.round(.5*ef)},t)),(0,a.jsx)(_.PY1.span,{className:"code-slots__wash","aria-hidden":"true",style:{clipPath:ew},children:(0,a.jsx)(_.PY1.span,{className:"code-slots__check",style:{transform:eE,opacity:eb},children:(0,a.jsx)("svg",{width:Math.round(.6*g),height:Math.round(.6*g),viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.4",strokeLinecap:"round",strokeLinejoin:"round",children:(0,a.jsx)("polyline",{points:"20 6 9 17 4 12"})})})}),(0,a.jsx)(_.PY1.span,{className:"code-slots__caret","aria-hidden":"true","data-show":eL?"":void 0,style:{transform:ey},children:(0,a.jsx)("span",{className:"code-slots__caret-line"},G)})]}),(0,a.jsx)("span",{id:`${O}-count`,className:"code-slots__sr","aria-live":"polite",children:"success"===l?"Code accepted":`${eM.filter(Boolean).length} of ${e} digits entered`})]})}function F(e){let t,r,i,o,l,s,u=(0,w.c)(20),{mv:c,drop:d,char:f,active:m,rise:h,sink:p}=e,[x,g]=(0,n.useState)(f);f&&f!==x&&g(f);let v=(0,S.G)(c,D);u[0]!==d||u[1]!==c?(t=[c,d],u[0]=d,u[1]=c,u[2]=t):t=u[2],u[3]!==h||u[4]!==p?(r=e=>{let[t,r]=e;return`translateY(${(1-t)*h+Math.max(r,0)*p}px)`},u[3]=h,u[4]=p,u[5]=r):r=u[5];let y=(0,S.G)(t,r);u[6]!==d||u[7]!==c?(i=[c,d],u[6]=d,u[7]=c,u[8]=i):i=u[8];let E=(0,S.G)(i,N),b=m?"":void 0,T=f?"":void 0;return u[9]!==v?(o=(0,a.jsx)(_.PY1.span,{className:"code-slots__fill",style:{transform:v}}),u[9]=v,u[10]=o):o=u[10],u[11]!==E||u[12]!==y||u[13]!==x?(l=x?(0,a.jsx)(_.PY1.span,{className:"code-slots__digit",style:{transform:y,opacity:E},children:x}):null,u[11]=E,u[12]=y,u[13]=x,u[14]=l):l=u[14],u[15]!==b||u[16]!==T||u[17]!==o||u[18]!==l?(s=(0,a.jsxs)("span",{className:"code-slots__slot","data-active":b,"data-filled":T,"aria-hidden":"true",children:[o,l]}),u[15]=b,u[16]=T,u[17]=o,u[18]=l,u[19]=s):s=u[19],s}function N(e){let[t,r]=e;return L(t)*(1-L(r/.6))}function D(e){return`scale(${Math.max(e,0)})`}r(8527);let z=`#version 300 es
const vec2 corners[3] = vec2[3](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
void main() {
  gl_Position = vec4(corners[gl_VertexID], 0.0, 1.0);
}`,k=`#version 300 es
precision highp float;
uniform vec2 uResolution;
uniform float uPixel;
uniform float uTime;
uniform float uLines;
uniform float uWidth;
uniform float uGlow;
uniform float uBrightness;
uniform float uHighlight;
uniform float uHighlightWidth;
uniform float uWarp;
uniform float uScale;
uniform float uRotation;
uniform vec3 uColor1;
uniform vec3 uColor2;
uniform vec3 uColor3;
uniform float uCycle;
uniform float uEdge;
uniform vec4 uMouse;
uniform vec4 uRipples[4];
uniform float uReveal;
uniform float uLight;
uniform float uOpacity;
out vec4 fragColor;

vec2 rotate(vec2 p, float a) {
  float c = cos(a);
  float s = sin(a);
  return vec2(c * p.x - s * p.y, s * p.x + c * p.y);
}

float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = p - i;
  vec2 w = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), w.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), w.x), w.y);
}

float smootherstep(float edge0, float edge1, float x) {
  float t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
  return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

float bend(vec2 p, float t) {
  vec2 q = p * 2.0 / uScale;
  float w = 0.6 * sin(q.x * 0.55 + t * 0.4 + 0.6 * sin(q.y * 0.9 - t * 0.28));
  w += 0.21 * sin(q.x * 1.3 - t * 0.33 + q.y * 0.8 + 1.3);
  w += 0.12 * sin(q.y * 2.3 + q.x * 0.9 - t * 0.37 + 0.4);
  return w * uWarp * uScale * 0.46;
}

float river(vec2 p, float y, float t) {
  float drift = 0.7 * (0.18 * sin(p.x * 1.6 - t * 0.33 + 0.7) + 0.1 * sin(p.x * 3.1 + t * 0.21));
  float center = 0.5 * (0.2 * sin(t * 0.17) + 0.08 * sin(t * 0.29 + 1.3));
  float width = 0.13 * uHighlightWidth;
  float near = (y - center - drift) / width;
  float far = (y + 0.22 * sin(t * 0.13 + 2.0) - drift * 0.6 + 0.3) / (width * 0.55);
  return max(exp(-near * near), exp(-far * far) * 0.7);
}

vec3 palette(float x) {
  x = fract(x) * 3.0;
  if (x < 1.0) return mix(uColor1, uColor2, smoothstep(0.0, 1.0, x));
  if (x < 2.0) return mix(uColor2, uColor3, smoothstep(1.0, 2.0, x));
  return mix(uColor3, uColor1, smoothstep(2.0, 3.0, x));
}

void main() {
  float aspect = uResolution.x / uResolution.y;
  vec2 uv = gl_FragCoord.xy / uResolution;
  vec2 p = rotate((gl_FragCoord.xy - 0.5 * uResolution) / uResolution.y, uRotation);
  float t = uTime;

  vec2 mouse = rotate(uMouse.xy, uRotation);
  vec2 toMouse = p - mouse;
  float lens = exp(-dot(toMouse, toMouse) / (uMouse.w * uMouse.w));
  p.y -= (p.y - mouse.y) * lens * uMouse.z;

  float ring = 0.0;
  for (int i = 0; i < 4; i++) {
    vec4 ripple = uRipples[i];
    if (ripple.w <= 0.0) continue;
    float x = (length(p - rotate(ripple.xy, uRotation)) - ripple.z * 0.6) / 0.08;
    float fade = exp(-ripple.z * 1.3) * smoothstep(0.0, 0.12, ripple.z);
    float bump = exp(-x * x);
    p.y -= x * bump * 0.07 * fade;
    ring += bump * fade;
  }

  float w = bend(p, t);
  float y = p.y + w;
  float phi = y * uLines;
  float fw = max(fwidth(phi), 1e-5);
  float crowd = smoothstep(0.18, 0.5, fw);

  float fold = smoothstep(1.3, 2.2, fw * uResolution.y / uLines);
  float shimmer = mix(1.0, smoothstep(0.15, 0.85, noise(vec2(y * 1.6 + t * 0.07, p.x * 0.55 - t * 0.22))), 0.5);
  float lit = max(river(p, y, t), fold * 0.9) * shimmer;
  float light = mix(1.0, 0.07 + 0.93 * lit, uHighlight);
  light += (1.0 - light) * min(lens * step(0.0001, uMouse.z) * 0.9 + ring * 0.6, 1.0);

  float dist = abs(fract(phi + 0.5) - 0.5) / fw;
  float width = uWidth * uPixel * (1.0 + mix(1.5, 0.6, uLight) * lit * uHighlight);
  float cover = clamp(min(dist + width * 0.5, 0.5) - max(dist - width * 0.5, -0.5), 0.0, 1.0);
  cover = mix(cover, min(width * fw, 1.0), crowd);
  float halo = exp(-dist / (2.2 * uPixel)) * (1.0 - crowd) * uGlow;
  float thread = mix(1.0, 0.55 + 0.45 * hash(vec2(floor(phi + 0.5), 7.3)), 0.45 * (1.0 - crowd));

  float span = 0.5 * sqrt(aspect * aspect + 1.0);
  float sweep = -span + (2.0 * span + 0.6) * uReveal;
  float reveal = 1.0 - smoothstep(sweep - 0.6, sweep, p.x);

  float edge = 1.0;
  if (uEdge > 0.0) {
    float ex = min(uv.x, 1.0 - uv.x) * aspect;
    float ey = min(uv.y, 1.0 - uv.y);
    edge = smootherstep(0.0, uEdge * 0.5, ex) * smootherstep(0.0, uEdge * 0.5, ey);
  }

  vec3 tint = palette(y * 0.3 + p.x * 0.2 + uCycle);
  float grain = (fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5) / 255.0;

  if (uLight > 0.5) {
    float low = min(tint.r, min(tint.g, tint.b));
    float chroma = max(tint.r, max(tint.g, tint.b)) - low;
    vec3 hue = (tint - low) / max(chroma, 1e-3);
    vec3 ink = mix(vec3(0.08), hue * 0.56 + 0.06, smoothstep(0.04, 0.2, chroma));
    float alpha = (cover + halo * 0.35) * thread * light * uBrightness * reveal * edge * 0.78 * uOpacity;
    alpha = clamp(alpha + grain, 0.0, 1.0);
    fragColor = vec4(ink * alpha, alpha);
    return;
  }

  float strength = (cover + halo) * thread * light * uBrightness * reveal * edge;
  vec3 color = clamp(tint * strength * uOpacity, 0.0, 1.0);
  float alpha = max(color.r, max(color.g, color.b));
  color = clamp(color + grain, 0.0, 1.0);
  fragColor = vec4(min(color, vec3(alpha)), alpha);
}`,U=(e,t,r)=>Math.min(r,Math.max(t,e)),I=e=>{let t=String(e||"").trim(),r=/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(t);if(r){let e=3===r[1].length?r[1].replace(/./g,e=>e+e):r[1];return[0,2,4].map(t=>parseInt(e.slice(t,t+2),16)/255)}let a=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(t);return a?[a[1],a[2],a[3]].map(e=>U(parseFloat(e)/255,0,1)):[1,1,1]},O=(e,t,r)=>{let a=e.createShader(t);return a?(e.shaderSource(a,r),e.compileShader(a),e.getShaderParameter(a,e.COMPILE_STATUS))?a:(console.error(e.getShaderInfoLog(a)),e.deleteShader(a),null):null},X=({color1:e="#ffffff",color2:t="#ffffff",color3:r="#ffffff",colorCycleSpeed:i=1,speed:o=.3,lineCount:l=72,lineWidth:s=1.3,glow:u=.6,brightness:c=1,highlight:d=1,highlightWidth:f=1,warpIntensity:m=1,warpScale:h=1,rotation:p=-33,edgeFade:x=0,enableMouseInteraction:g=!0,mouseInfluence:v=2,clickRipple:y=!0,intro:w=!0,lightMode:E=!1,opacity:b=1,maxDevicePixelRatio:T=2,className:R="",style:S})=>{let _=(0,n.useRef)(null),M=(0,n.useRef)(null),L=(0,n.useRef)(null),[A,C]=(0,n.useState)(0),j={color1:I(e),color2:I(t),color3:I(r),cycleSpeed:i,speed:Math.max(0,o),lines:U(l,2,400),width:U(s,.25,12),glow:Math.max(0,u),brightness:Math.max(0,c),highlight:U(d,0,1),highlightWidth:U(f,.2,5),warp:U(m,0,3),scale:U(h,.2,4),rotation:p*Math.PI/180,edge:U(x,0,1),mouse:g,influence:U(v,0,3),clickRipple:y,intro:w,light:E,opacity:U(b,0,1),maxRatio:U(T,.5,3)},P=(0,n.useRef)(j);return P.current=j,(0,n.useEffect)(()=>{L.current?.()}),(0,n.useEffect)(()=>{let e=_.current,t=M.current;if(!e||!t)return;let r=t.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1,powerPreference:"high-performance"}),a=r?(e=>{let t=O(e,e.VERTEX_SHADER,z),r=O(e,e.FRAGMENT_SHADER,k),a=t&&r?e.createProgram():null;if(!t||!r||!a)return t&&e.deleteShader(t),r&&e.deleteShader(r),null;if(e.attachShader(a,t),e.attachShader(a,r),e.linkProgram(a),e.deleteShader(t),e.deleteShader(r),!e.getProgramParameter(a,e.LINK_STATUS))return console.error(e.getProgramInfoLog(a)),e.deleteProgram(a),null;let n={},i=e.getProgramParameter(a,e.ACTIVE_UNIFORMS);for(let t=0;t<i;t++){let r=e.getActiveUniform(a,t);r&&(n[r.name.replace(/\[0\]$/,"")]=e.getUniformLocation(a,r.name))}return{program:a,uniforms:n}})(r):null;if(!r||!a)return;let n=window.matchMedia("(prefers-reduced-motion: reduce)").matches,i=r.createVertexArray(),o={width:1,height:1,ratio:1},l={x:0,y:0,inside:!1},s={x:0,y:0,presence:0,ready:!1},u=[],c=new Float32Array(16),d=60*Math.random(),f=0,m=P.current.intro&&!n&&0===A?0:1,h=0,p=0,x=!0,g="hidden"!==document.visibilityState,v=!1,y=()=>{let r=P.current,a=e.getBoundingClientRect(),n=Math.max(1,a.width),i=Math.max(1,a.height),l=Math.min(window.devicePixelRatio||1,r.maxRatio,Math.sqrt(24e5/(n*i))),s=Math.max(1,Math.round(n*l)),u=Math.max(1,Math.round(i*l));(t.width!==s||t.height!==u)&&(t.width=s,t.height=u),o.width=n,o.height=i,o.ratio=s/n},w=(e,t)=>[(e-o.width/2)/o.height,(o.height/2-t)/o.height],E=e=>{if(h=0,v)return;let y=P.current,b=U((e-p)/1e3||0,0,.05);p=Math.max(p,e),d+=b*y.speed*2.5*(n?.25:1),f+=b*y.speed*y.cycleSpeed*.05,m<1&&(m=Math.min(1,m+b/1.8));let T=y.mouse&&l.inside&&!n;if(T){let[e,t]=w(l.x,l.y);s.ready||(s.x=e,s.y=t,s.ready=!0);let r=1-Math.exp(-(10*b));s.x+=(e-s.x)*r,s.y+=(t-s.y)*r}let R=+!!T;s.presence+=(R-s.presence)*(1-Math.exp(-(5*b))),s.presence<.002&&!T&&(s.ready=!1);for(let e=u.length-1;e>=0;e--)u[e].age+=b,u[e].age>2.6&&u.splice(e,1);c.fill(0),u.forEach((e,t)=>{c[4*t]=e.x,c[4*t+1]=e.y,c[4*t+2]=e.age,c[4*t+3]=1});let S=1-Math.pow(1-m,3);r.viewport(0,0,t.width,t.height),r.useProgram(a.program),r.bindVertexArray(i);let _=a.uniforms;r.uniform2f(_.uResolution,t.width,t.height),r.uniform1f(_.uPixel,o.ratio),r.uniform1f(_.uTime,d),r.uniform1f(_.uLines,y.lines),r.uniform1f(_.uWidth,y.width),r.uniform1f(_.uGlow,y.glow),r.uniform1f(_.uBrightness,y.brightness),r.uniform1f(_.uHighlight,y.highlight),r.uniform1f(_.uHighlightWidth,y.highlightWidth),r.uniform1f(_.uWarp,y.warp*(.25+.75*S)),r.uniform1f(_.uScale,y.scale),r.uniform1f(_.uRotation,y.rotation),r.uniform3f(_.uColor1,y.color1[0],y.color1[1],y.color1[2]),r.uniform3f(_.uColor2,y.color2[0],y.color2[1],y.color2[2]),r.uniform3f(_.uColor3,y.color3[0],y.color3[1],y.color3[2]),r.uniform1f(_.uCycle,f),r.uniform1f(_.uEdge,y.edge),r.uniform4f(_.uMouse,s.x,s.y,s.presence*y.influence*.16,.2),r.uniform4fv(_.uRipples,c),r.uniform1f(_.uReveal,S),r.uniform1f(_.uLight,+!!y.light),r.uniform1f(_.uOpacity,y.opacity),r.drawArrays(r.TRIANGLES,0,3);let M=Math.abs(R-s.presence)>.002;(y.speed>0&&!n||m<1||M||u.length>0||T)&&x&&g&&(h=requestAnimationFrame(E))},b=()=>{!h&&!v&&x&&g&&(p=performance.now(),h=requestAnimationFrame(E))};L.current=()=>{y(),b()};let T=t=>{let r=e.getBoundingClientRect();return{x:t.clientX-r.left,y:t.clientY-r.top,inside:t.clientX>=r.left&&t.clientX<=r.right&&t.clientY>=r.top&&t.clientY<=r.bottom}},R=e=>{let t=T(e);l.x=t.x,l.y=t.y,l.inside=t.inside,b()},S=e=>{let t=P.current,r=T(e);if(!r.inside||!t.clickRipple||n)return;let[a,i]=w(r.x,r.y);u.push({x:a,y:i,age:0}),u.length>4&&u.shift(),b()},j=()=>{l.inside=!1,b()},F=e=>{"mouse"!==e.pointerType&&j()};window.addEventListener("pointermove",R,{passive:!0}),window.addEventListener("pointerdown",S,{passive:!0}),window.addEventListener("pointerup",F,{passive:!0}),window.addEventListener("pointercancel",F,{passive:!0}),document.documentElement.addEventListener("pointerleave",j);let N=e=>{e.preventDefault(),v=!0,cancelAnimationFrame(h),h=0},D=()=>C(e=>e+1);t.addEventListener("webglcontextlost",N),t.addEventListener("webglcontextrestored",D);let I=new ResizeObserver(()=>{y(),b()});I.observe(e);let X=new IntersectionObserver(e=>{x=e.some(e=>e.isIntersecting),b()});X.observe(e);let B=()=>{g="hidden"!==document.visibilityState,b()};return document.addEventListener("visibilitychange",B),y(),b(),()=>{cancelAnimationFrame(h),L.current=null,I.disconnect(),X.disconnect(),window.removeEventListener("pointermove",R),window.removeEventListener("pointerdown",S),window.removeEventListener("pointerup",F),window.removeEventListener("pointercancel",F),document.documentElement.removeEventListener("pointerleave",j),document.removeEventListener("visibilitychange",B),t.removeEventListener("webglcontextlost",N),t.removeEventListener("webglcontextrestored",D),r.isContextLost()||(r.deleteVertexArray(i),r.deleteProgram(a.program))}},[A]),(0,a.jsx)("div",{ref:_,className:`line-waves${R?` ${R}`:""}`,style:S,children:(0,a.jsx)("canvas",{ref:M,className:"line-waves__canvas","aria-hidden":"true"})})};var B=r(91),$=r(2380);function q(){let e=(0,i.useRouter)(),{isPaired:t,isLoading:r,isAuthenticated:s,isSessionExpired:u,tunnelStatus:c,tunnelError:d,restartTunnel:f,refreshSession:m}=(0,o.A)(),[h,p]=(0,n.useState)(""),[x,g]=(0,n.useState)("idle"),[v,w]=(0,n.useState)(!1),[E,b]=(0,n.useState)(null),[T,R]=(0,n.useState)(!1),[S,M]=(0,n.useState)(!1);(0,n.useEffect)(()=>{!r&&s&&e.push("/dashboard")},[r,s,e]),(0,n.useEffect)(()=>{if(s)return;let e=setInterval(()=>{m()},3e3);return()=>clearInterval(e)},[s,m]);let L=(0,n.useCallback)(async t=>{let r=t.trim().toUpperCase();if(r&&!(r.length<6)){w(!0),b(null);try{await (0,l.ZD)(r),g("success");let t=await m();setTimeout(()=>{t?.paired&&(t?.tunnel_ready||t?.tunnel_status),e.push("/dashboard")},700)}catch(e){g("error"),b(e&&"object"==typeof e&&"detail"in e?String(e.detail):e instanceof Error?e.message:"Invalid or expired code. Please verify and try again.")}finally{w(!1)}}},[m,e]),A=async()=>{try{let e=await navigator.clipboard.readText();if(e){let t=e.trim().toUpperCase().slice(0,6);p(t),R(!0),setTimeout(()=>R(!1),1500),6===t.length&&L(t)}}catch{}},C=async()=>{M(!0);try{await f()}finally{M(!1)}};return(0,a.jsxs)("main",{className:"relative min-h-[100dvh] w-full bg-[#050507] text-[#f4f4f5] flex flex-col items-center justify-center p-4 sm:p-6 overflow-hidden select-none font-sans",children:[(0,a.jsxs)("div",{className:"fixed inset-0 z-0 pointer-events-none overflow-hidden opacity-45",children:[(0,a.jsx)(X,{color1:"#71717a",color2:"#3f3f46",color3:"#18181b",speed:.2,lineCount:68,lineWidth:1.2,highlight:.8,warpIntensity:.85,rotation:-32,enableMouseInteraction:!1,clickRipple:!1,intro:!1}),(0,a.jsx)("div",{className:"absolute inset-0 bg-radial from-transparent via-[#050507]/60 to-[#050507]"})]}),(0,a.jsxs)(_.PY1.div,{initial:{opacity:0,y:16,scale:.96},animate:{opacity:1,y:0,scale:1},transition:{duration:.5,ease:[.16,1,.3,1]},className:"relative z-10 w-full max-w-[400px] sm:max-w-[420px] rounded-[32px] p-7 sm:p-9 bg-[#0b0b0e]/95 backdrop-blur-2xl border border-white/[0.08] shadow-[0_24px_80px_rgba(0,0,0,0.85)] flex flex-col items-center",children:[(0,a.jsx)("div",{className:"relative w-44 h-44 sm:w-48 sm:h-48 rounded-full overflow-hidden border border-white/[0.09] bg-[#020203] shadow-[inset_0_0_28px_rgba(0,0,0,0.95)] flex items-center justify-center",children:(0,a.jsx)(y,{src:"/logo.png",size:.65,fill:!0,color:"#ffffff",blur:15,lensSize:.3,lensSoftness:.7,chroma:.12,idle:!0,className:"w-full h-full"})}),(0,a.jsx)("h1",{className:"text-[25px] sm:text-[27px] font-semibold text-white tracking-tight mt-6 text-center",children:"Enter the code"}),(0,a.jsx)("p",{className:"text-[13px] text-zinc-400 text-center max-w-[280px] mt-2 leading-relaxed font-normal",children:"We sent you a code to your email, please enter to verify your address."}),t&&!u&&"starting"===c&&(0,a.jsxs)("div",{className:"w-full mt-6 space-y-3",children:[(0,a.jsxs)("div",{className:"p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 text-center space-y-2",children:[(0,a.jsx)("div",{className:"flex justify-center",children:(0,a.jsx)($.xNY,{className:"w-5 h-5 text-zinc-300 animate-spin"})}),(0,a.jsx)("div",{className:"text-[13px] font-medium text-white",children:"Launching Tunnel Bridge..."}),(0,a.jsx)("p",{className:"text-[11px] text-zinc-500 font-mono",children:"Syncing keys with central orchestrator"})]}),(0,a.jsx)("button",{onClick:()=>e.push("/dashboard"),type:"button",className:"w-full h-11 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-[13px] font-medium flex items-center justify-center transition-colors",children:"Enter Local Dashboard"})]}),t&&!u&&"failed"===c&&(0,a.jsxs)("div",{className:"w-full mt-6 space-y-3",children:[(0,a.jsxs)("div",{className:"p-3.5 rounded-2xl bg-red-950/20 border border-red-900/30 text-center space-y-1",children:[(0,a.jsxs)("div",{className:"flex items-center justify-center gap-1.5 text-red-400 text-[12px] font-medium",children:[(0,a.jsx)($.sFm,{className:"w-4 h-4"}),(0,a.jsx)("span",{children:"Tunnel Bridge Offline"})]}),(0,a.jsx)("p",{className:"text-[11px] text-zinc-400 font-mono truncate px-2",children:d||"Check network connection"})]}),(0,a.jsx)("button",{onClick:C,disabled:S,type:"button",className:"w-full h-11 rounded-2xl bg-white hover:bg-zinc-200 text-black font-medium text-[13px] flex items-center justify-center gap-2 transition-colors disabled:opacity-50",children:S?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)($.xNY,{className:"w-4 h-4 animate-spin"}),(0,a.jsx)("span",{children:"Retrying Bridge..."})]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)($.Xbb,{className:"w-4 h-4"}),(0,a.jsx)("span",{children:"Restart Tunnel"})]})}),(0,a.jsx)("button",{onClick:()=>e.push("/dashboard"),type:"button",className:"w-full text-center text-[11px] text-zinc-500 hover:text-zinc-300 transition-colors",children:"Continue locally without tunnel"})]}),(!t||u)&&(0,a.jsxs)("div",{className:"w-full mt-7 flex flex-col items-center",children:[(0,a.jsx)("div",{className:"flex justify-center",children:(0,a.jsx)(P,{length:6,value:h,status:x,onChange:e=>{p(e),"idle"!==x&&g("idle"),E&&b(null)},onComplete:L,accentColor:"#f4f4f5",inkColor:"#f4f4f5",slotColor:"#16161a",digitColor:"#09090b",dangerColor:"#ef4444",slotSize:46,gap:8,radius:12,bounce:.2,settle:.3,rise:8,cascade:20,autoFocus:!0})}),(0,a.jsx)(B.N,{children:E&&(0,a.jsxs)(_.PY1.div,{initial:{opacity:0,y:-4},animate:{opacity:1,y:0},exit:{opacity:0,y:-4},className:"mt-3 text-[11.5px] text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-1.5 flex items-center gap-1.5 text-center",children:[(0,a.jsx)($.sFm,{className:"w-3.5 h-3.5 shrink-0 text-red-400"}),(0,a.jsx)("span",{children:E})]})}),(0,a.jsx)("div",{className:"mt-4 flex items-center gap-3",children:v?(0,a.jsxs)("div",{className:"flex items-center gap-2 text-[12px] text-zinc-400 font-mono py-1",children:[(0,a.jsx)($.xNY,{className:"w-3.5 h-3.5 animate-spin text-zinc-200"}),(0,a.jsx)("span",{children:"Verifying code..."})]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("button",{type:"button",onClick:A,className:"text-[11.5px] font-mono text-zinc-400 hover:text-zinc-200 flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-900/60 border border-zinc-800/80 hover:border-zinc-700 transition-colors",children:T?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)($.s0,{className:"w-3 h-3 text-emerald-400"}),(0,a.jsx)("span",{className:"text-emerald-400",children:"Pasted"})]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)($.YnX,{className:"w-3 h-3"}),(0,a.jsx)("span",{children:"Paste code"})]})}),6===h.length&&(0,a.jsxs)("button",{type:"button",onClick:()=>L(h),className:"text-[11.5px] font-mono text-white hover:text-zinc-200 flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 transition-colors",children:[(0,a.jsx)("span",{children:"Submit"}),(0,a.jsx)($.D8V,{className:"w-3 h-3"})]})]})})]}),(0,a.jsx)("div",{className:"mt-8 pt-2 text-center",children:(0,a.jsxs)("p",{className:"text-[12.5px] text-zinc-500",children:["Need Help?"," ",(0,a.jsx)("a",{href:"https://cachette.cloud",target:"_blank",rel:"noopener noreferrer",className:"text-zinc-300 hover:text-white underline underline-offset-4 transition-colors font-medium",children:"Contact us"})]})}),(0,a.jsxs)("div",{className:"mt-6 pt-4 border-t border-white/[0.05] w-full flex items-center justify-between text-[10px] font-mono text-zinc-600",children:[(0,a.jsx)("span",{children:"CACHETTE PROTOCOL"}),(0,a.jsxs)("span",{className:"flex items-center gap-1.5 text-zinc-500",children:[(0,a.jsx)("span",{className:"w-1.5 h-1.5 rounded-full bg-emerald-500/80"}),"ENCLAVE SECURE"]})]})]})]})}},2399:()=>{},5556:(e,t,r)=>{"use strict";r.d(t,{A:()=>s,AuthProvider:()=>l});var a=r(5155),n=r(2115),i=r(9406);let o=(0,n.createContext)(null);function l({children:e}){let[t,r]=(0,n.useState)(!1),[s,u]=(0,n.useState)("unpaired"),[c,d]=(0,n.useState)(!1),[f,m]=(0,n.useState)(null),[h,p]=(0,n.useState)(null),[x,g]=(0,n.useState)(null),[v,y]=(0,n.useState)(!1),[w,E]=(0,n.useState)(!1),[b,T]=(0,n.useState)(null),[R,S]=(0,n.useState)(!0),_=(0,n.useCallback)(async()=>{try{let e=await (0,i.lz)();return e.paired&&e.session_token?((0,i.Ui)(e.session_token,e.session_token_expires_at),r(!0),u(e.tunnel_status||"unpaired"),d(!!e.tunnel_ready),m(e.tunnel_error||null),p(e.user||null),g(e.session_token_expires_at||null),T({node_id:e.node_id,subdomain:e.subdomain}),(e=>{if(!e)return E(!1);try{let t=new Date(e).getTime(),r=Date.now(),a=t-r;a<=0?(y(!0),E(!1)):a<864e5?E(!0):E(!1)}catch{E(!1)}})(e.session_token_expires_at)):(r(!1),u("unpaired"),d(!1),m(null),p(null),(0,i.h7)()),e}catch(e){return console.warn("Failed to fetch node session:",e),null}finally{S(!1)}},[]),M=async()=>{try{u("starting"),m(null),await (0,i.Q1)(),await _()}catch(e){m(e instanceof Error?e.message:"Failed to trigger tunnel restart"),u("failed")}};return(0,n.useEffect)(()=>{_();let e=(0,i.z1)(()=>{y(!0)});return()=>{e()}},[_]),(0,a.jsx)(o.Provider,{value:{isPaired:t,isLoading:R,isAuthenticated:t&&!v&&(c||"ready"===s),tunnelStatus:s,tunnelReady:c,tunnelError:f,user:h,sessionTokenExpiresAt:x,isSessionExpired:v,isExpiringSoon:w,nodeInfo:b,refreshSession:_,restartTunnel:M,dismissSessionExpired:()=>{y(!1)},logout:()=>{(0,i.h7)(),p(null),r(!1),y(!1)}},children:e})}function s(){let e=(0,n.useContext)(o);if(!e)throw Error("useAuth must be used within AuthProvider");return e}},8371:(e,t,r)=>{Promise.resolve().then(r.bind(r,1766))},8527:()=>{},9406:(e,t,r)=>{"use strict";function a(){return localStorage.getItem("session_token")}function n(e,t){localStorage.setItem("session_token",e),t&&localStorage.setItem("session_token_expires_at",t)}function i(){localStorage.removeItem("session_token"),localStorage.removeItem("session_token_expires_at")}r.d(t,{Ak:()=>w,JM:()=>g,L$:()=>S,Lc:()=>v,Q1:()=>f,T2:()=>p,Ui:()=>n,XV:()=>b,YP:()=>E,ZD:()=>m,aO:()=>x,bq:()=>R,h7:()=>i,he:()=>y,lz:()=>d,s_:()=>T,yF:()=>h,z1:()=>l});let o=new Set;function l(e){return o.add(e),()=>{o.delete(e)}}function s(){o.forEach(e=>{try{e()}catch(e){console.error("Error in session expired listener:",e)}})}async function u(e,t={}){let r=a(),n={"Content-Type":"application/json",...t.headers};r&&(n.Authorization=`Bearer ${r}`);let i=await fetch(`${e}`,{...t,headers:n});if(401===i.status)throw s(),new c(401,"Session expired or invalid — please re-pair from central dashboard");if(!i.ok){let e=await i.json().catch(()=>({}));throw new c(i.status,e.detail||"Request failed")}return 204===i.status?{}:i.json()}class c extends Error{constructor(e,t){super(t),this.status=e,this.name="ApiError"}}async function d(){return u("/api/v1/node-pairing/session")}async function f(){return u("/api/v1/node-pairing/tunnel/restart",{method:"POST"})}async function m(e,t){return u("/api/v1/node-pairing/claim",{method:"POST",body:JSON.stringify({pairing_code:e,central_url:t})})}async function h(e){let t=e?`?folder_id=${e}`:"";return u(`/api/v1/files${t}`)}async function p(e,t){return u("/api/v1/files/folders",{method:"POST",body:JSON.stringify({name:e,parent_id:t||null})})}async function x(e){return u(`/api/v1/files/folders/${e}`,{method:"DELETE"})}async function g(e){let t=a(),r={};t&&(r.Authorization=`Bearer ${t}`);let n=await fetch(`/api/v1/files/${e}/download`,{headers:r});if(!n.ok)throw 401===n.status&&s(),Error(`Download failed: ${n.status}`);let i=n.headers.get("Content-Disposition"),o="download";if(i){let e=i.match(/filename\*?=(?:UTF-8''|")?(.*?)(?:"|;|$)/i);e?.[1]&&(o=decodeURIComponent(e[1]))}let l=await n.blob(),u=URL.createObjectURL(l),c=document.createElement("a");c.href=u,c.download=o,document.body.appendChild(c),c.click(),document.body.removeChild(c),URL.revokeObjectURL(u)}async function v(e,t){return u(`/api/v1/files/${e}`,{method:"PATCH",body:JSON.stringify({name:t})})}async function y(e,t){return u(`/api/v1/files/folders/${e}`,{method:"PATCH",body:JSON.stringify({name:t})})}async function w(e){return u(`/api/v1/files/${e}`,{method:"DELETE"})}async function E(e,t="view"){return u(`/api/v1/files/${e}/share`,{method:"POST",body:JSON.stringify({access_level:t})})}async function b(e,t,r,a){return u("/api/v1/files/uploads/initate",{method:"POST",body:JSON.stringify({filename:e,size:t,content_type:r,folder_id:a||null})})}async function T(e,t){let r=a(),n={};r&&(n.Authorization=`Bearer ${r}`);let i=new FormData;i.append("file",t);let o=await fetch(`/api/v1/files/${e}/upload`,{method:"POST",headers:n,body:i});if(401===o.status&&s(),!o.ok){let e=await o.json().catch(()=>({}));throw new c(o.status,e.detail||"Upload failed")}return o.json()}async function R(e,t,r){let n=a(),i={"Content-Type":"application/octet-stream"};n&&(i.Authorization=`Bearer ${n}`);let o=await fetch(`/api/v1/files/uploads/${e}/part?part_number=${t}`,{method:"PUT",headers:i,body:r});if(401===o.status&&s(),!o.ok){let e=await o.json().catch(()=>({}));throw new c(o.status,e.detail||"Part upload failed")}return o.json()}async function S(e,t){return u(`/api/v1/files/uploads/${e}/complete`,{method:"POST",body:JSON.stringify({parts:t})})}},9557:()=>{}},e=>{e.O(0,[280,204,771,441,826,358],()=>e(e.s=8371)),_N_E=e.O()}]);