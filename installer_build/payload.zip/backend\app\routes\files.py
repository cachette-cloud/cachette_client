import shutil
from pathlib import Path
from app import dependencies
from sqlalchemy import SelectLabelStyle
from sqlalchemy import select
import uuid
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Query, UploadFile, Request, File as FastAPIFile
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.dependencies import get_current_node_user, require_owner, get_s3_service, rate_limit_user, general_limiter
from app.models.user import UserCache
from app.models.file import File
from app.models.folder import Folder
from app.models.share import Share
from app.schema.file import UploadInitiate, UploadInitiateResponse, CompleteUpload, CompletePart, FileOut, DirectoryListing, FolderOut, FolderCreate, ItemRename, DownloadUrlResponse
from app.schema.share import ShareCreate, ShareOut
from app.service.s3_service import s3_service
from app.config import settings, get_current_subdomain
from app.core.slug import generate_share_slug

router = APIRouter(prefix="/files", tags = ["files"])

@router.post("/uploads/initiate", response_model=UploadInitiateResponse, dependencies=[Depends(rate_limit_user(general_limiter))])
@router.post("/uploads/initate", response_model=UploadInitiateResponse, dependencies=[Depends(rate_limit_user(general_limiter))], include_in_schema=False, deprecated=True)
async def initiate_upload(
    body: UploadInitiate,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service),
):
    if body.size > settings.MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail=f"file exceeds max size of {settings.MAX_FILE_SIZE} bytes")
    
    existing_file = await db.execute(
        select(File).where(
            File.owner_id == current_user.id,
            File.folder_id == body.folder_id,
            File.filename == body.filename,
            File.status == "active"
        )
    )
    if existing_file.scalars().first():
        raise HTTPException(400, "A file with this name already exists in this folder")
    
    # Per-user quota check
    if current_user.storage_used + body.size > current_user.storage_quota_bytes:
        remaining = current_user.storage_quota_bytes - current_user.storage_used
        raise HTTPException(413, f"Storage quota exceeded. {remaining} bytes remaining")

    # Node-wide disk capacity cap: reject uploads if free disk space is insufficient
    storage_path = Path(settings.CACHETTE_DATA_DIR)
    if not storage_path.exists():
        storage_path = storage_path.parent
    try:
        _, _, free_disk_bytes = shutil.disk_usage(storage_path)
    except Exception:
        free_disk_bytes = float("inf")

    if body.size > free_disk_bytes:
        raise HTTPException(413, f"Node storage capacity exceeded: Insufficient disk space on node ({free_disk_bytes} bytes free)")

    file_id = uuid.uuid4()
    key = f"users/{current_user.id}/{file_id}"

    upload_id = None
    upload_mode = "single"
    if body.size >= settings.MULTIPART_THRESHOLD:
        upload_id = await s3.create_multipart_upload(key=key, content_type=body.content_type)
        upload_mode = "multipart"

    fil_row = File(
        id=file_id,
        owner_id=current_user.id,
        s3_key=key,
        filename=body.filename,
        size=body.size,
        content_type=body.content_type,
        status="uploading",
        upload_id=upload_id,
        folder_id=body.folder_id,
    )
    db.add(fil_row)
    await db.commit()

    return UploadInitiateResponse(
        file_id=file_id,
        upload_mode=upload_mode,
        upload_id=upload_id,
    )
    
@router.post("/{file_id}/upload")
async def upload_single(
    file_id: uuid.UUID,
    file: UploadFile,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)

    if not file_row or file_row.owner_id != current_user.id:
        raise HTTPException(404, "file not found")
    if file_row.status != "uploading":
        raise HTTPException(400, "upload not in progress")
    if file_row.size > current_user.storage_quota_bytes - current_user.storage_used:
        await s3.delete_object(key=file_row.s3_key)
        await db.delete(file_row)
        await db.commit()
        raise HTTPException(413, "File size exceeds maximum allowed size")
    
    data = await file.read()
    await s3.put_object_bytes(key=file_row.s3_key, content_type=file_row.content_type, body=data)

    file_row.status = "active"
    await db.commit()

    return {"status": "uploaded"}

@router.put("/uploads/{file_id}/part")
async def upload_part(
    file_id: uuid.UUID,
    part_number: int,
    request: Request,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)

    if not file_row or file_row.owner_id != current_user.id:
        raise HTTPException(404, "file not found")
    if file_row.status != "uploading":
        raise HTTPException(400, "upload not in progress")
    if not file_row.upload_id:
        raise HTTPException(400, "Upload is not configured for multipart chunks (missing upload_id)")

    content_type = request.headers.get("content-type", "")
    if "multipart/form-data" in content_type:
        form = await request.form()
        part_file = form.get("part") or form.get("file")
        if isinstance(part_file, UploadFile):
            data = await part_file.read()
        else:
            data = await request.body()
    else:
        data = await request.body()

    if not data:
        raise HTTPException(400, "No chunk data provided")

    etag = await s3.upload_part_bytes(
        key=file_row.s3_key,
        upload_id=file_row.upload_id,
        part_number=part_number,
        body=data,
    )

    return {"part_number": part_number, "etag": etag}


@router.post("/uploads/{file_id}/part-url", dependencies = [Depends(rate_limit_user(general_limiter))])
async def get_part_url(
    file_id: uuid.UUID,
    part_number: int,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id:
        raise HTTPException(400, "file not found")
    if file_row.status != "uploading":
        raise HTTPException(400, "upload not in progress")
    if not file_row.upload_id:
        raise HTTPException(400, "Upload is not configured for multipart chunks (missing upload_id)")

    url = await s3.generate_part_upload_url(
        key=file_row.s3_key,
        upload_id=file_row.upload_id,
        part_number=part_number,
    )

    return {"part_number": part_number, "url": url}


@router.post("/uploads/{file_id}/complete")
async def complete_upload(
    file_id: uuid.UUID,
    body: CompleteUpload,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id:
        raise HTTPException(400, "file not found")
    
    if file_row.upload_id:
        await s3.complete_multipart_upload(
            key=file_row.s3_key,
            upload_id=file_row.upload_id,
            parts=[{"PartNumber": p.part_number, "ETag": p.etag} for p in body.parts],
        )
    else:
       exists = await s3.object_exists(key=file_row.s3_key)
       if not exists:
           raise HTTPException(400, "File was not uploaded")

    if current_user.storage_used + file_row.size > current_user.storage_quota_bytes:
        await s3.delete_object(key=file_row.s3_key)
        await db.delete(file_row)
        await db.commit()
        raise HTTPException(403, "Storage quota exceeded")
    
    file_row.status = "active"
    current_user.storage_used += file_row.size
    await db.commit()

    return {"file_id": file_id, "status": "active"}

@router.post("/upload/{file_id}/abort", dependencies = [Depends(rate_limit_user(general_limiter))])
async def abort_upload(
    file_id: uuid.UUID,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id:
        raise HTTPException(404, "File not found")
    
    if file_row.upload_id:
        await s3.abort_multipart_upload(key=file_row.s3_key, upload_id=file_row.upload_id)
    await db.delete(file_row)
    await db.commit()
    return {"status": "aborted"}
    
    
@router.delete("/{file_id}", dependencies = [Depends(rate_limit_user(general_limiter))])
async def delete_file(
    file_id: uuid.UUID,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id:
        raise HTTPException(404, "File not found")

    await s3.delete_object(key=file_row.s3_key)
    current_user.storage_used -= file_row.size
    await db.delete(file_row)
    await db.commit()
    return {"status": "deleted"}



@router.get("/{file_id}/download", response_model=DownloadUrlResponse, dependencies=[Depends(rate_limit_user(general_limiter))])
async def get_download_url(
    file_id: uuid.UUID,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id or file_row.status != "active":
        raise HTTPException(404, "File not found")

    stream = s3.get_object_stream(key=file_row.s3_key)

    return StreamingResponse(
        stream,
        media_type=file_row.content_type,
        headers={
            "Content-Disposition": f"attachment; filename={file_row.filename}"
        }
    )



@router.patch("/{file_id}", response_model=FileOut, dependencies=[Depends(rate_limit_user(general_limiter))])
async def rename_file(
    file_id: uuid.UUID,
    body: ItemRename,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id or file_row.status != "active":
        raise HTTPException(404, "File not found")

    # Check for duplicates in same folder
    existing_file = await db.execute(
        select(File).where(
            File.owner_id == current_user.id,
            File.folder_id == file_row.folder_id,
            File.filename == body.name,
            File.status == "active",
            File.id != file_id
        )
    )
    if existing_file.scalars().first():
        raise HTTPException(400, "A file with this name already exists in this folder")

    file_row.filename = body.name
    await db.commit()
    await db.refresh(file_row)
    return file_row

@router.post("/folders", response_model=FolderOut, dependencies=[Depends(rate_limit_user(general_limiter))])
async def create_folder(
    body: FolderCreate,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
):
    if body.parent_id:
        parent_folder = await db.get(Folder, body.parent_id)
        if not parent_folder or parent_folder.owner_id != current_user.id:
            raise HTTPException(404, "Parent folder not found")

    existing_folder = await db.execute(
        select(Folder).where(
            Folder.owner_id == current_user.id,
            Folder.parent_id == body.parent_id,
            Folder.name == body.name
        )
    )
    if existing_folder.scalars().first():
        raise HTTPException(400, "A folder with this name already exists")

    new_folder = Folder(
        owner_id=current_user.id,
        parent_id=body.parent_id,
        name=body.name
    )
    db.add(new_folder)
    await db.commit()
    await db.refresh(new_folder)
    return new_folder

@router.patch("/folders/{folder_id}", response_model=FolderOut, dependencies=[Depends(rate_limit_user(general_limiter))])
async def rename_folder(
    folder_id: uuid.UUID,
    body: ItemRename,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
):
    folder_row = await db.get(Folder, folder_id)
    if not folder_row or folder_row.owner_id != current_user.id:
        raise HTTPException(404, "Folder not found")

    # Check for duplicates in same parent folder
    existing_folder = await db.execute(
        select(Folder).where(
            Folder.owner_id == current_user.id,
            Folder.parent_id == folder_row.parent_id,
            Folder.name == body.name,
            Folder.id != folder_id
        )
    )
    if existing_folder.scalars().first():
        raise HTTPException(400, "A folder with this name already exists")

    folder_row.name = body.name
    await db.commit()
    await db.refresh(folder_row)
    return folder_row

@router.delete("/folders/{folder_id}", dependencies = [Depends(rate_limit_user(general_limiter))])
async def delete_folder(
    folder_id: uuid.UUID,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
    s3: s3_service = Depends(get_s3_service)
):
    target_folder = await db.get(Folder, folder_id)
    if not target_folder or target_folder.owner_id != current_user.id:
        raise HTTPException(404, "Folder not found")

    async def delete_folder_recursive(fid: uuid.UUID):
        # 1. Get subfolders
        sub_folders_res = await db.execute(select(Folder).where(Folder.parent_id == fid))
        sub_folders = sub_folders_res.scalars().all()
        for sf in sub_folders:
            await delete_folder_recursive(sf.id)
            
        # 2. Get files in this folder
        files_res = await db.execute(select(File).where(File.folder_id == fid))
        files = files_res.scalars().all()
        
        for f in files:
            await s3.delete_object(key=f.s3_key)
            current_user.storage_used -= f.size
            await db.delete(f)
            
        # 3. Delete this folder
        curr_folder = await db.get(Folder, fid)
        if curr_folder:
            await db.delete(curr_folder)
            
    await delete_folder_recursive(folder_id)
    await db.commit()
    return {"status": "deleted"}

@router.get("", response_model=DirectoryListing, dependencies=[Depends(rate_limit_user(general_limiter))])
async def list_directory(
    folder_id: Optional[uuid.UUID] = Query(None, description="Folder to list; omit for root"),
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
):
    folder = None
    if folder_id is not None:
        folder = await db.get(Folder, folder_id)
        if not folder or folder.owner_id != current_user.id:
            raise HTTPException(404, "folder not found")
    
    #get folders in dir
    folders_result = await db.execute(
        select(Folder).where(Folder.owner_id == current_user.id, Folder.parent_id == folder_id)
    )
    subfolders = folders_result.scalars().all()

    files_result = await db.execute(
        select(File).where(
            File.owner_id == current_user.id,
            File.folder_id == folder_id,
            File.status == "active"
        )
    )
    files = files_result.scalars().all()

    return DirectoryListing(
        folder=FolderOut.model_validate(folder) if folder else None,
        folders=[FolderOut.model_validate(f) for f in subfolders],
        files=[FileOut.model_validate(f) for f in files],
    )

@router.get("/{file_id}", response_model=FileOut, dependencies=[Depends(rate_limit_user(general_limiter))])
async def get_file(
    file_id: uuid.UUID,
    current_user: UserCache = Depends(get_current_node_user),
    db: AsyncSession = Depends(get_db),
):
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id or file_row.status != "active":
        raise HTTPException(404, "File not found")
    return file_row


def build_share_url(slug: str, request_base_url: Optional[str] = None) -> str:
    """Build full public share URL using this node's known subdomain or request base URL."""
    subdomain = get_current_subdomain()
    if subdomain:
        return f"https://{subdomain}.cachette.cloud/s/{slug}"
    if request_base_url:
        return f"{request_base_url.rstrip('/')}/s/{slug}"
    return f"http://localhost:8000/s/{slug}"


# Product decision: public share link generation is restricted to the node owner.
@router.post(
    "/{file_id}/share",
    response_model=ShareOut,
    dependencies=[Depends(require_owner), Depends(rate_limit_user(general_limiter))],
)
async def create_or_get_file_share(
    file_id: uuid.UUID,
    body: ShareCreate,
    request: Request,
    current_user: UserCache = Depends(require_owner),
    db: AsyncSession = Depends(get_db),
):
    """
    Create or reuse a public share link for a file with the given access_level (view or download).
    Owner-only, returns the full public URL on this node's subdomain.
    """
    file_row = await db.get(File, file_id)
    if not file_row or file_row.owner_id != current_user.id or file_row.status != "active":
        raise HTTPException(status_code=404, detail="File not found")

    # Reuse an existing share for this file+access_level pair if one exists
    stmt = select(Share).where(
        Share.file_id == file_id,
        Share.access_level == body.access_level,
    )
    result = await db.execute(stmt)
    share = result.scalars().first()

    if not share:
        # Generate a unique, short, random, non-sequential slug
        for _ in range(5):
            candidate_slug = generate_share_slug(length=10)
            existing_slug = await db.execute(select(Share).where(Share.slug == candidate_slug))
            if not existing_slug.scalars().first():
                break
        else:
            candidate_slug = generate_share_slug(length=12)

        share = Share(
            id=uuid.uuid4(),
            file_id=file_id,
            access_level=body.access_level,
            slug=candidate_slug,
        )
        db.add(share)
        await db.commit()
        await db.refresh(share)

    base_url = str(request.base_url) if request else None
    share_url = build_share_url(share.slug, request_base_url=base_url)

    return ShareOut(
        id=share.id,
        file_id=share.file_id,
        access_level=share.access_level,
        slug=share.slug,
        url=share_url,
        created_at=share.created_at or datetime.now(timezone.utc),
    )
